const express = require('express');
const { check } = require('express-validator');
const validator = require('validator'); // Added import
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const authMiddleware = require('../middleware/auth');
const validate = require('../middleware/validate');
const AuditLog = require('../models/AuditLog');
const router = express.Router();

router.get('/', authMiddleware(), async (req, res) => {
  try {
    let cart = await Cart.findOne({ user: req.user.id }).populate('items.product');
    if (!cart) {
      cart = new Cart({ user: req.user.id, items: [], total: 0 });
      await cart.save();
    }
    res.json(cart);
  } catch (err) {
    console.error('Get cart error:', err);
    res.status(500).json({ msg: 'Server error fetching cart' });
  }
});

router.post(
  '/',
  authMiddleware(),
  [
    check('productId').isMongoId().withMessage('Invalid product ID'),
    check('quantity').isInt({ min: 1 }).withMessage('Quantity must be a positive integer'),
  ],
  validate,
  async (req, res) => {
    const { productId, quantity } = req.body;
    try {
      const product = await Product.findById(productId);
      if (!product) {
        return res.status(404).json({ msg: 'Product not found' });
      }
      let cart = await Cart.findOne({ user: req.user.id });
      if (!cart) {
        cart = new Cart({ user: req.user.id, items: [], total: 0 });
      }
      const itemIndex = cart.items.findIndex(item => item.product.toString() === productId);
      if (itemIndex > -1) {
        cart.items[itemIndex].quantity += quantity;
      } else {
        cart.items.push({ product: productId, quantity });
      }
      cart.total = cart.items.reduce((sum, item) => {
        const itemProduct = item.product._id ? item.product : product;
        return sum + item.quantity * itemProduct.price;
      }, 0);
      await cart.save();
      await AuditLog.create({ user: req.user.id, action: 'add-to-cart', details: `Added ${quantity} of product ${productId} to cart` });
      res.json(cart);
    } catch (err) {
      console.error('Add to cart error:', err);
      res.status(500).json({ msg: 'Server error adding to cart' });
    }
  }
);

router.delete('/:productId', authMiddleware(), async (req, res) => {
  try {
    let cart = await Cart.findOne({ user: req.user.id });
    if (!cart) {
      return res.status(404).json({ msg: 'Cart not found' });
    }
    cart.items = cart.items.filter(item => item.product.toString() !== req.params.productId);
    cart.total = cart.items.reduce((sum, item) => {
      return sum + item.quantity * item.product.price;
    }, 0);
    await cart.save();
    await AuditLog.create({ user: req.user.id, action: 'remove-from-cart', details: `Removed product ${req.params.productId} from cart` });
    res.json(cart);
  } catch (err) {
    console.error('Remove from cart error:', err);
    res.status(500).json({ msg: 'Server error removing from cart' });
  }
});

module.exports = router;