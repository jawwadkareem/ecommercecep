const express = require('express');
const { check } = require('express-validator');
const validator = require('validator'); // Added import
const User = require('../models/User');
const authMiddleware = require('../middleware/auth');
const validate = require('../middleware/validate');
const AuditLog = require('../models/AuditLog');
const router = express.Router();

router.get('/profile', authMiddleware(), async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password -resetPasswordToken -resetPasswordExpires');
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }
    res.json(user);
  } catch (err) {
    console.error('Get profile error:', err);
    res.status(500).json({ msg: 'Server error fetching profile' });
  }
});

router.put(
  '/profile',
  authMiddleware(),
  [
    check('name').trim().isLength({ min: 2, max: 50 }).withMessage('Name must be between 2 and 50 characters'),
    check('email').optional().isEmail().withMessage('Invalid email address'),
    check('address').optional().trim().isLength({ max: 200 }).withMessage('Address cannot exceed 200 characters'),
  ],
  validate,
  async (req, res) => {
    const { name, email, address } = req.body;
    try {
      const user = await User.findById(req.user.id);
      if (!user) {
        return res.status(404).json({ msg: 'User not found' });
      }
      if (email && email !== user.email) {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
          return res.status(400).json({ msg: 'Email already registered' });
        }
        if (!validator.isEmail(email)) {
          return res.status(400).json({ msg: 'Invalid email address' });
        }
        user.email = email;
      }
      user.name = name;
      user.address = address || user.address;
      await user.save();
      await AuditLog.create({ user: user._id, action: 'update-profile', details: `User ${user.email} updated profile` });
      res.json({ user: { id: user._id, email: user.email, name: user.name, address: user.address, role: user.role } });
    } catch (err) {
      console.error('Update profile error:', err);
      res.status(500).json({ msg: 'Server error updating profile' });
    }
  }
);

module.exports = router;