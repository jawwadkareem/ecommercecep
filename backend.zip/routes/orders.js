const express = require('express');
const validator = require('validator'); // Added import
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const authMiddleware = require('../middleware/auth');
const AuditLog = require('../models/AuditLog');
const router = express.Router();

router.get('/', authMiddleware(), async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user.id }).populate('items.product');
    res.json(orders);
  } catch (err) {
    console.error('Get orders error:', err);
    res.status(500).json({ msg: 'Server error fetching orders' });
  }
});

router.post('/', authMiddleware(), async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user.id }).populate('items.product');
    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ msg: 'Cart is empty' });
    }
    const total = cart.items.reduce((sum, item) => sum + item.quantity * item.product.price, 0);
    const order = new Order({
      user: req.user.id,
      items: cart.items.map(item => ({
        product: item.product._id,
        quantity: item.quantity,
      })),
      total,
    });
    await order.save();
    await Cart.findOneAndUpdate({ user: req.user.id }, { items: [], total: 0 });
    await AuditLog.create({ user: req.user.id, action: 'create-order', details: `Order ${order._id} created` });
    res.status(201).json({ order, msg: 'Order created successfully' });
  } catch (err) {
    console.error('Create order error:', err);
    res.status(500).json({ msg: 'Server error creating order' });
  }
});

module.exports = router;