const express = require('express');
const { check } = require('express-validator');
const validator = require('validator'); // Added import
const authMiddleware = require('../middleware/auth');
const validate = require('../middleware/validate');
const AuditLog = require('../models/AuditLog');
const router = express.Router();

router.get('/csrf-token', authMiddleware(), async (req, res) => {
  try {
    const csrfToken = require('crypto').randomBytes(32).toString('hex');
    res.json({ csrfToken });
  } catch (err) {
    console.error('Get CSRF token error:', err);
    res.status(500).json({ msg: 'Server error generating CSRF token' });
  }
});

router.post(
  '/process',
  authMiddleware(),
  [
    check('amount').isFloat({ min: 0 }).withMessage('Amount must be a positive number'),
    check('cardNumber').custom((value) => {
      // Basic card number validation (16 digits, no spaces)
      const cleanCard = value.replace(/\s/g, '');
      if (!validator.isLength(cleanCard, { min: 16, max: 16 }) || !validator.isNumeric(cleanCard)) {
        throw new Error('Card number must be 16 digits');
      }
      return true;
    }),
  ],
  validate,
  async (req, res) => {
    const { amount, cardNumber } = req.body;
    try {
      // Simulate payment processing
      const transactionId = require('crypto').randomBytes(16).toString('hex');
      await AuditLog.create({
        user: req.user.id,
        action: 'process-payment',
        details: `Payment of $${amount} processed with transaction ${transactionId}`,
      });
      res.json({ transactionId, msg: 'Payment processed successfully' });
    } catch (err) {
      console.error('Process payment error:', err);
      res.status(500).json({ msg: 'Server error processing payment' });
    }
  }
);

module.exports = router;